Bismillah. Basillion Display Font is a first font that made by Ihdytype. 
It is a 100% free! You can you use it for PERSONAL or COMMERCIAL USED. 
I just ask you for using it well and wisely. 
Thankyou.

https://www.behance.net/ihsanrusydy